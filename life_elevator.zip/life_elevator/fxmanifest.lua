fx_version 'cerulean'
game 'gta5'

author '[LIFESERVICES/LIFE SCRIPTS]//code by Alpha#7721 and Preacher#6392'
description 'Elevator Script for ESX'
version '1.0'

client_scripts {
  '@NativeUI/NativeUI.lua',
  'config.lua',
  'client/client.lua',
}
