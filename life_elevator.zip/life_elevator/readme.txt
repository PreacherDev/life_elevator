Script by Life Scripts
code by Alpha#7721 and Preacher#6392


If you have any questions about the script or if there is any bug/issue join our discord and open a ticket: https://discord.gg/rFAhWWUPuX
If the link expires add Preacher#6392 or Alpha#7721 on discord.

You can edit almost everything through the config.lua and the menuclient.lua! 
Need changes? Also create a Ticket.

Tested on all ESX Versions! Works fine we guess..

Any suggestions? Use our suggestion channel.

Thank you and have fun!

#LifeScripts